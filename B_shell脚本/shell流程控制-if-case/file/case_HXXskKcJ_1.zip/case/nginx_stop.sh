nginx_stop (){
  if [ ! -e $nginx_pid  ]; then
    action "nginx已经停止" /bin/true
    else
      systemctl stop nginx
       status=$(netstat -lntp |grep 80 | grep -w "^tcp" | wc -l)
       if [ $status -eq 0 ]; then
            action "nginx已经成功停止"  /bin/true
         else
           action "nignx启动失败"  /bin/false

       fi

  fi
}