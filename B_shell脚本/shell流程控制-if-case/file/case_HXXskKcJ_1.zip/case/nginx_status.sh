
status(){
  systemctl status nginx &> /dev/null
  case $(echo $?) in
  4)
    action "服务没有安装"  /bin/false

   esac

}