ngingf (){
  ansible-playbook nginx.yml
  echo "priority=1" >> /etc/yum.repos.d/nginx.repo
  ansible-playbook nginxinstall.yml
}