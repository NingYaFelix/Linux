
nginx_start (){
  #首先判断进程pid是否存在，已经存在说明进程已存在
  if [ -e $nginx_pid ];then
      action "nginx进程已启动"   /bin/true
  else
      systemctl start $server &> /dev/null
      #判断nginx80端口是否有，没有则nginx没启动
      status=$(netstat -lntp |grep 80 | grep -w "^tcp" | wc -l)
      if [ $status -eq 1 ];then
        action "$server已成功启动"  /bin/true
        else
          #判断是否安装，如若没有安装则进入安装菜单
          systemctl start $server &> /dev/null
        if [ $(echo $?) -eq 5 ]; then
          action "$server未安装启动失败"   /bin/false
          read -p "是否进行安装$server服务:[yes|no]" check
          if [ $check == yes ];then

            #配置安装菜单操作
            nginx_install (){
              cat <<-EOF
              ********nginx安装*******
              |  1）确认安装$server    |
              |  2）后悔了不装了      |
              |  3）退出             |
              ***********************
EOF
            }
            nginx_install
            #进入上图所需的操作2
                  while true
                  do

                   #判断用户输入的选项
                   read -p "请输入你要执行的操作[1|2|3] " nginx_check
                   case $nginx_check in
                   1)
                     read -p "是否使用官方源进行安装[yes|no]" install
                     action "$server 正在安装,请稍后。。。。"

                     yum install yum-priorities -y >> /dev/null
                       case $install in
                        yes)
                            yum install ansible -y >> /dev/null
                             ansible-playbook ./nginx.yml  &> /dev/null
                             echo ""priority=1" >> /etc/yum.repos.d/nginx.repo" &> /dev/null
                             ansible-playbook ./nginxinstal.yml  &> /dev/null
                         ;;

                        no)
                          yum install nginx -y >> /dev/null
                       esac
                      nginx_start  #如果已经安装则进行启动的操作，再次进行判断是否启动
                     ;;

                   2)
                     action "正在退出安装"
                      break  #退出安装直接退出循环
                     ;;
                   *)
                    break
                     ;;
                   esac

                   done
              #如果用户输入no则直接退出程序
                elif [ $check == no  ]; then
                  sleep 1
              exit
              #如果用户输出不是yes也不是no则直接退出安装程序
            elif  [ $check != yes ]&&[ $check != no ]; then
                echo "输入错误，即将退出"
                sleep 1


          fi
      fi

fi
      fi
}