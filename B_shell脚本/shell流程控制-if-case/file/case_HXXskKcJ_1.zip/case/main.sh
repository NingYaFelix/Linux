#!/usr/bin/bash
# -*-Shell-script-*-

#######################################
# 函数说明：功能函数，打印主机菜单、菜单栏，标题自动居中，弹性伸缩，自动生成
# 未决问题：标题若包含英文则生成菜单有瑕疵，但不明显
# 全局变量：无
# Arguments:
#   $1 : 菜单栏清单数组(array)
#   $2 : 菜单宽度(int)
#   $3 : 菜单标题(string)
# 输出： 输出到STDOUT
# 原创开发者：ShenShuilong
# Mail：2315313866@qq.com
#######################################
menu_host() {
	# 定义主机数据
	Host=($1)
	# 定义列长度
	menu_lie=$2
	# 定义行长度
	menu_hang=$[ ${#Host[@]} + 2 ]
	# 定义标题居中相关变量
	host_name="$3"
	echo "\$1 == ${Host[1]}"
	echo "\$2 == ${2}"
	echo "\$3 == ${3}"
	#exit;
	Host_name_len=$[ ${#host_name} * 2 ]
	Host_name_len_begin=$[ ($menu_lie - $Host_name_len) / 2 ]
	Host_name_len_end=$[ Host_name_len_begin + Host_name_len -1 ]
	# 外循环控制行
	for (( hang = 1; hang <= menu_hang; hang++ )); do

		# 当第一行和最后一行时 打印一行-符号
		if [[ ${hang} -eq 1 ||  ${hang} -eq ${menu_hang}  ]]; then

			# 内循环控制列
			for (( lie = 1; lie <= menu_lie; lie++ )); do
				# 进来后说明${hang}为1或最后一行，这时判断${lie}是否为1或者最后一列
				if [[ ${lie} -eq 1 || ${lie} -eq ${menu_lie} ]]; then
					# 如果条件匹配则输出+号不换行，并跳出当次循环
					printf "+";
					continue;
				fi

				# 当为${hang}为1且列为${Host_name_len_begin}时，插入${host_name}
				if [[  ${hang} -eq 1 && ${lie} -eq ${Host_name_len_begin}  ]]; then
					printf "${host_name}"
					# 插入完${host_name}后，需要重新定义lie的长度：begin开始长度 + ${host_name}长度
					lie=${Host_name_len_end}	# 功能：实现标题居中
					continue;
				fi

				# 条不符合则打印 "-"
				printf "-";
			done
			#每行结束后都打印一遍换行符
			printf "\n";

			# 如果if进来则说明是第一行或最后一行，则不用执行下面的所有操作，跳出外循环
			continue;
		fi


		# 中间循环打印主机清单数组
		# 由于外循环${hang}初始值为1，且第1行不打印主机清单，则需要${hang} - 2将index初始值为0
		index=$[ ${hang} - 2 ]
		# 这里计算Host数组中每个元素的长度并+4，因为printf中的" ${index}) "长度等于4
		Host_len=$[ ${#Host[index]} + 4 ]
		# 用总长度 + Host_len = 空格填充次数
		old_len=$[ menu_lie - Host_len ]
		# 打印既定的每个ip地址，然后不换行，后面用空格填充${old_len}次数后用|结尾并换行
		printf " ${index}) ${Host[index]}";

		for (( lie = 1; lie <= old_len ; lie++ )); do

			# 判断${lie}为最后一列时需要用"|"结尾并换行
			if [[ ${lie} -eq old_len ]]; then

				# 第2行打印附加信息
				if [[ ${hang} -eq 2 ]]; then
					printf "| 作    者：Shuilong Shen\n";
					continue;
				fi

				# 第3行打印附加信息
				if [[ ${hang} -eq 3 ]]; then
					printf "|指导老师:江湖人称标杆徐\n";
					continue;
				fi
				#if [[ help -eq 1 ]]; then # help帮助菜单暂未开发中
				#	printf "|\n h)help"
				#fi
				printf "| \n";
				continue;
			fi
			# 填充空格
			printf " ";
		done
	done
}
