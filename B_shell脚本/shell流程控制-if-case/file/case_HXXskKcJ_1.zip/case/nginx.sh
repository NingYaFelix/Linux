#!/usr/bin/env bash
. /etc/init.d/functions
. ./main.sh
. ./nginx_start.sh
. ./nginx_stop.sh
server=nginx
inv_menu=(nginx_install nginx_stop nginx_start nginx_status)
nginx_pid=/var/run/$server.pid


stop (){
  nginx_stop
}
#执行选项操作
nginx_menu() {
  menu_host "${inv_menu[*]}" 60 "开源web系统"
}
start(){
  nginx_start
}
nginx_menu
read -p "请输入你要执行的操作（0|1|2|3）" status
  case $status in
      0)
        start
        ;;
      1)
        stop
        ;;
      2)
        stop
        start
        ;;
      3)
        #判断nginx状态，根据输出的数字
          systemctl status nginx &> /dev/null
          case $(echo $?) in
             4)
               #判断服务是否安装，若没安装让用户选择是否安装
                action "服务没有安装"  /bin/false
                read -p "是否进行安装[yes|no]" i
                case $i in
                yes)
                  start
                  ;;
                no)
                  exit
                esac
                ;;
            0)
              #判断服务是否启动，若没启动，则让用户选择是否启动
              action "服务已经启动" /bin/true
              read -p "是否关闭服务[yes|no]" t
              case $t in
                yes)
                  stop
                  sleep 1
                  action "服务已成功关闭" /bin/true
                  ;;
                no)
                  exit
              esac
              ;;
            3)
              #判断服务是否启动，若启动，则让用户选择是否关闭
              action "服务未启动" /bin/false
              read -p "是否进行启动[yes|no]" s
              case $s in
              yes)
                start
                action "服务已成功开启" /bin/true
                ;;
              no)
                exit

              esac



          esac

  esac




