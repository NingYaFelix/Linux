#!/usr/bin/bash

key=$1
redis-cli -p 6379 info | grep "\<${key}\>" | awk -F ':' '{print $NF}'
