#!/usr/bin/bash

domain="status.oldxu.net"
uri_path=/ngx_status

case $1 in
	active)
		curl -s -HHost:${domain} http://127.0.0.1/${uri_path} | awk 'NR==1 {print $NF}'
		;;

	accepts)
		curl -s -HHost:${domain} http://127.0.0.1/${uri_path} | awk 'NR==3 {print $1}'
		;;

	handled)
		curl -s -HHost:${domain} http://127.0.0.1/${uri_path} | awk 'NR==3 {print $2}'
		;;

	requests)
		curl -s -HHost:${domain} http://127.0.0.1/${uri_path} | awk 'NR==3 {print $3}'
		;;
	
	reading)
		curl -s -HHost:${domain} http://127.0.0.1/${uri_path} | awk 'NR==4 {print $2}'
		;;

	writing)
		curl -s -HHost:${domain} http://127.0.0.1/${uri_path} | awk 'NR==4 {print $4}'
		;;

	waiting)
		curl -s -HHost:${domain} http://127.0.0.1/${uri_path} | awk 'NR==4 {print $6}'
		;;

	*)
		echo "Usage $0 { active | accepts | handled | requests | reading | writing | waiting }"
esac
